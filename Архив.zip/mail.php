<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Подключаем классы PHPMailer (укажи правильный путь)
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

$mail = new PHPMailer(true);
$mail->CharSet = 'UTF-8';

try {
    // Получаем данные из формы
    $surname         = $_POST['surname'] ?? '';
    $name            = $_POST['name'] ?? '';
    $lastname        = $_POST['last-name'] ?? '';
    $phone           = $_POST['phone'] ?? '';
    $email           = $_POST['email'] ?? '';
    $site            = $_POST['site'] ?? '';
    $siteCount       = $_POST['site-count'] ?? '';
    $orgForm         = $_POST['org-form'] ?? '';
    $accessPerson    = $_POST['access-person'] ?? '';
    $accessSubscribe = $_POST['access-subscribe'] ?? '';

    // Настройки SMTP Beget
    $mail->isSMTP();
    $mail->Host       = 'smtp.beget.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'info@nv-che.ru'; // логин почтового ящика
    $mail->Password   = 'W!1fSIMTJV4%';   // пароль от почты
    $mail->SMTPSecure = 'ssl';
    $mail->Port       = 465;

    // От кого
    $mail->setFrom('info@nv-che.ru', 'Сайт nv-che.ru');

    // Кому
    $mail->addAddress('webdmitriev@gmail.com');

    // Тело письма
    $mail->isHTML(true);
    $mail->Subject = 'Новая заявка с сайта nv-che.ru';
    $mail->Body = "
        <h2>Новая заявка</h2>
        <p><strong>Фамилия:</strong> $surname</p>
        <p><strong>Имя:</strong> $name</p>
        <p><strong>Отчество:</strong> $lastname</p>
        <p><strong>Телефон:</strong> $phone</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Сайт:</strong> $site</p>
        <p><strong>Посещаемость:</strong> $siteCount</p>
        <p><strong>Орг. форма:</strong> $orgForm</p>
        <p><strong>Согласие на обработку данных:</strong> $accessPerson</p>
        <p><strong>Согласие на рассылку:</strong> $accessSubscribe</p>
    ";

    $mail->AltBody = "Фамилия: $surname\nИмя: $name\nТелефон: $phone\nEmail: $email\nСайт: $site";

    // Отправка письма
    $mail->send();
    header('Location: /');
    exit;

} catch (Exception $e) {
    echo "Ошибка отправки письма: {$mail->ErrorInfo}";
}
